#!/bin/bash


myArray=(1 2 3 manju ganesh 3333)

echo "first element of an array: ${myArray[0]}"

echo "All elements of an array: ${myArray[@]}"
