#!/bin/bash

#First line is Shebang line which will indicate this script will use bash shell to execute shell commands


<<multi_line_comments

This is multi line comments

need to use <<[option]

but we need to end this multi line comment with [option]

multi_line_comments


#Create variable called name with value Manju


name=Manju

echo "My name is $name"

age=25

echo "I am $age years old"

place=Bengaluru

echo "I am from $place"

